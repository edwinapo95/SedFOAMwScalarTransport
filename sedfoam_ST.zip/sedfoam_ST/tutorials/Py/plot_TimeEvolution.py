#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Dec 10 18:13:23 2019

@author: chauchat
"""

"""
Read and Plot a time series of OpenFoam scalar field
====================================================

This example reads and plots a time series of an OpenFoam scalar field
"""

###############################################################################
# Gets the time directories
# -------------------------
#
# .. note:: Tries if directory is a number and adds it in the time array
import os
import subprocess
import numpy as np
import fluidfoam
from pylab import *
import matplotlib.gridspec as gridspec

#
# Change fontsize
#
matplotlib.rcParams.update({'font.size': 20})
mpl.rcParams['lines.linewidth'] = 3
mpl.rcParams['lines.markersize'] = 5
mpl.rcParams['lines.markeredgewidth'] = 1
#
# Change subplot sizes
#
gs = gridspec.GridSpec(1, 5)
gs.update(left=0.1, right=0.95, top=0.95,
          bottom=0.1, wspace=0.125, hspace=0.25)
#
# Figure size
#
figwidth = 12
figheight = 6

#########################################
# Loading OpenFoam results
#########################################
basepath = '../'

caseList = ['1DOscill']
labelList = ['sedFoam']
tmax=16
umax=1.2

figName = './DNSOscill'

t,dpdx,dpdy,dpdz=np.loadtxt(basepath+caseList[0]+'/gradPOSC.txt',unpack=True)

Ncase=len(caseList)

k=-1
for case in caseList:
    k = k + 1
    sol = basepath + case + '/'
    X,Y,Z = fluidfoam.readmesh(sol)
    # Reading SedFoam results
    dir_list = os.listdir(sol)
    time_list = []

    for directory in dir_list:
        try:
            float(directory)
            time_list.append(directory)
        except:
            pass
    time_list.sort(key=float)
    time_list.remove(time_list[0])
    time_list=np.array(time_list)
    
    time_series = np.empty(0)
    for timename in time_list:
        Ub = fluidfoam.readvector(sol, timename, 'Ub')
        time_series = np.append(time_series, Ub[0,-1])

    plt.figure(0)

    # Converts strings to float for plot
    time_list = np.array([float(i) for i in time_list])
    plt.plot(time_list, time_series,label=labelList[k])
    plt.plot(t, dpdx/1727.85,label='dpdx')

    plt.plot([0 ,tmax],[0, 0],'--k')
    plt.legend(loc=4,fontsize=8)
    # Setting axis labels
    plt.xlabel('t (s)')
    plt.ylabel('Ub (m/s)')
    plt.xlim([0,tmax])    
    plt.ylim([-umax,umax])
    
savefig(figName+'.png', facecolor='w', edgecolor='w', format='png')
