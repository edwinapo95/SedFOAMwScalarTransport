sedfoam
=======

[![Release](https://img.shields.io/badge/release-3.0alpha-blue.svg)](http://github.com/SedFoam/sedfoam)
[![Build Status](https://travis-ci.com/SedFoam/sedfoam.svg?branch=master)](https://travis-ci.com/SedFoam/sedfoam)
[![OpenFOAM v1806](https://img.shields.io/badge/OpenFOAM-v1806-brightgreen.svg)](https://openfoam.com/)
[![OpenFOAM v1712](https://img.shields.io/badge/OpenFOAM-v1712-brightgreen.svg)](https://openfoam.com/)
[![OpenFOAM 6](https://img.shields.io/badge/OpenFOAM-6-brightgreen.svg)](https://openfoam.org/)
[![OpenFOAM 5.x](https://img.shields.io/badge/OpenFOAM-5.x-brightgreen.svg)](https://openfoam.org/)
[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.1320016.svg)](https://doi.org/10.5281/zenodo.1320016)

This repository provides the SedFoam solver (version OpenFOAM classic).

[![](https://i.ibb.co/WgS6PYB/Capture-d-e-cran-2018-12-14-a-11-27-01.png)](https://www.youtube.com/watch?v=cVf7qm_ZDK0)

Status
------

The sedfoam solver is in development and is not yet fully functional.

Pull requests are encouraged!

Features
--------

A three-dimensional two-phase flow solver, SedFoam-3.0, has been developed for sediment transport applications. The solver is extended from twoPhaseEulerFoam available in the 2.1.0 release of the open-source CFD (computational fluid dynamics) toolbox OpenFOAM. In this approach the sediment phase is modeled as a continuum, and constitutive laws have to be prescribed for the sediment stresses. In the proposed solver, two different intergranular stress models are implemented: the kinetic theory of granular flows and the dense granular flow rheology μ(I). For the fluid stress, laminar or turbulent flow regimes can be simulated and three different turbulence models are available for sediment transport: a simple mixing length model (one-dimensional configuration only), a k − ε, and a k − ω model.

Installation
------------

```bash
cd $WM_PROJECT_USER_DIR
git clone https://github.com/sedfoam/sedfoam sedfoam
cd sedfoam
./Allwclean
./Allwmake
```


Usage
-----

There are tutorials located in `tutorials` and details can be found here : http://servforge.legi.grenoble-inp.fr/pub/soft-sedfoam


Publications
------------

Julien Chauchat, Zhen Cheng, Tim Nagel, Cyrille Bonamy, and Tian-Jian Hsu (2017) [SedFoam-2.0: a 3-D two-phase flow numerical model for sediment transport ](Geosci. Model Dev., 10, 4367-4392) [![DOI](https://img.shields.io/badge/DOI-10.5195%2Fgmd_10_4367_2017-blue.svg)](https://doi.org/10.5194/gmd-10-4367-2017)

How to cite
-----------

The sedfoam solver can be cited via DOI thanks to Zenodo: [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.1320016.svg)](https://doi.org/10.5281/zenodo.1320016)


Developers
----------

* Cyrille Bonamy
* Julien Chauchat
* Zhen Cheng
* Tian-Jian Hsu
* Tim Nagel
* Antoine Mathieu


Acknowledgements
----------------
Most of the developments were carried out on MILLS/FARBER at the University of Delaware, on HPC resources from GENCI-
CINES (Grant 2015-x2016017567) and on the Froggy platform of the [CIMENT infrastructure](https://ciment.ujf-grenoble.fr), which is supported by the Rhone-Alpes region (GRANT CPER07-13 CIRA) and the Equip@Meso project (reference ANR-
10-EQPX-29-01) of the programme Investissements d’Avenir supervised by the Agence Nationale pour la Recherche.

The developers would also like to acknowledge the support from the program on "Fluid-Mediated Particle Transport in Geo-
physical Flows" at the Kavli Institute for Theoretical Physics, Santa Barbara, USA. The laboratory LEGI is part of the LabEx Tec 21 (Investissements d’Avenir - grant agreement nANR-11-LABX-0030) and Labex OSUG@2020 (ANR10 LABX56).

OpenFOAM is free, open source software for computational fluid dynamics (CFD),
developed primarily by [CFD Direct](http://cfd.direct), on behalf of the
[OpenFOAM](http://openfoam.org) Foundation.

LICENSE AND COPYRIGHT
---------------------
License GNU GPL version 2 or later
Copyright (C) 2015-2018 LEGI UMR5519, CNRS, UGA, G-INP, Grenoble.
